//
//  KKAlbumAssetModalVideoPlayController.h
//  BM
//
//  Created by sjyt on 2020/4/7.
//  Copyright © 2020 bm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KKMPBaseUI.h"

@class KKAlbumAssetModal;

NS_ASSUME_NONNULL_BEGIN

@interface KKAlbumAssetModalVideoPlayController : KKMPBaseViewController

- (instancetype)initWitKKAlbumAssetModal:(KKAlbumAssetModal*)aKKAlbumAssetModal;

@end

NS_ASSUME_NONNULL_END
