//
//  KKAlbumImagePickerImageViewController.h
//  HeiPa
//
//  Created by liubo on 2019/3/13.
//  Copyright © 2019 gouuse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KKMPBaseUI.h"

@interface KKAlbumImagePickerImageViewController : KKMPBaseViewController

@end
