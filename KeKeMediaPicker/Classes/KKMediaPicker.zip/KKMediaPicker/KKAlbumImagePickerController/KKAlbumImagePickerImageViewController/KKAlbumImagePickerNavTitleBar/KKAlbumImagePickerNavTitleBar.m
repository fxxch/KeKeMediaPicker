//
//  KKAlbumImagePickerNavTitleBar.m
//  BM
//
//  Created by sjyt on 2020/3/23.
//  Copyright © 2020 bm. All rights reserved.
//

#import "KKAlbumImagePickerNavTitleBar.h"
#import "KKAlbumImagePickerManager.h"
#import "KKMediaTool.h"

@implementation KKAlbumImagePickerNavTitleBar

- (void)dealloc{
    [NSNotificationCenter.defaultCenter removeObserver:self name:NotificationName_KKAlbumManagerLoadSourceFinished object:nil];
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(Notification_KKAlbumManagerLoadSourceFinished:) name:NotificationName_KKAlbumManagerLoadSourceFinished object:nil];
    }
    return self;
}

- (void)initUI{
    NSString *title = KKMediaPicker_Album_Photo;
    CGSize size = [title kkmp_sizeWithFont:[UIFont systemFontOfSize:17] maxWidth:1000];
    CGFloat width = 10 + size.width + 10 + 20 + 5;
    
    self.backgroundView = [[UIButton alloc] initWithFrame:CGRectMake((self.frame.size.width-width)/2.0, (self.frame.size.height-44)+(44-30)/2.0, width, 30)];
    self.backgroundView.backgroundColor = KKMediaPicker_Clolor_707070;
    [self.backgroundView addTarget:self action:@selector(backgroundViewClicked) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.backgroundView];
    self.backgroundView.layer.cornerRadius = 15;
    self.backgroundView.layer.masksToBounds = YES;
    self.backgroundView.userInteractionEnabled = NO;
    
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 10 + size.width + 10, self.backgroundView.frame.size.height)];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.font = [UIFont systemFontOfSize:17];
    self.titleLabel.text = title;
    self.titleLabel.backgroundColor = [UIColor clearColor];
    [self.backgroundView addSubview:self.titleLabel];
    self.titleLabel.userInteractionEnabled = NO;

    self.arrowButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.arrowButton.frame = CGRectMake(self.titleLabel.frame.origin.x+self.titleLabel.frame.size.width, (self.backgroundView.frame.size.height-20)/2.0, 20, 20);
    self.arrowButton.backgroundColor = [UIColor lightGrayColor];
    UIImage *image01 = [KKAlbumManager themeImageForName:@"NavArrowDown"];
    [self.arrowButton setImage:image01 forState:UIControlStateNormal];
    self.arrowButton.layer.cornerRadius = self.arrowButton.frame.size.width/2.0;
    self.arrowButton.layer.masksToBounds = YES;
    [self.backgroundView addSubview:self.arrowButton];
    self.arrowButton.userInteractionEnabled = NO;
    self.hidden = YES;
}

- (void)backgroundViewClicked{
    if (self.isOpen) {
        [self close];
        if (self.delegate && [self.delegate respondsToSelector:@selector(KKAlbumImagePickerNavTitleBar_Open:)]) {
            [self.delegate KKAlbumImagePickerNavTitleBar_Open:NO];
        }
    } else {
        [self open];
        if (self.delegate && [self.delegate respondsToSelector:@selector(KKAlbumImagePickerNavTitleBar_Open:)]) {
            [self.delegate KKAlbumImagePickerNavTitleBar_Open:YES];
        }
    }
}

- (void)close{
    if (self.isOpen==NO) return;
    self.isOpen = NO;
    CGAffineTransform endAngle = CGAffineTransformMakeRotation(0*(M_PI/180.0f));
    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        self.arrowButton.transform = endAngle;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)open{
    if (self.isOpen==YES) return;
    self.isOpen = YES;
    CGAffineTransform endAngle = CGAffineTransformMakeRotation(180*(M_PI/180.0f));
    [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveLinear animations:^{
        self.arrowButton.transform = endAngle;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)Notification_KKAlbumManagerLoadSourceFinished:(NSNotification*)notice{
    NSArray *aArray = notice.object;
    if (aArray==nil || aArray.count==0) {
        self.backgroundView.userInteractionEnabled = NO;
        self.hidden = YES;
    } else {
        self.backgroundView.userInteractionEnabled = YES;
        self.hidden = NO;
        NSArray *array = notice.object;
        for (NSInteger i=0; i<[array count]; i++) {
            KKAlbumDirectoryModal *data = (KKAlbumDirectoryModal*)[array objectAtIndex:i];
            if ([data.title isEqualToString:KKMediaPicker_Album_UserLibrary]) {
                [self reloadWithDirectoryModal:data];
                break;
            }
        }
    }
}

- (void)reloadWithDirectoryModal:(KKAlbumDirectoryModal*)aModal{
    NSString *title = aModal.title;
    CGSize size = [title kkmp_sizeWithFont:[UIFont systemFontOfSize:17] maxWidth:1000];
    CGFloat width = 10 + size.width + 10 + 20 + 5;
    
    self.backgroundView.frame = CGRectMake((self.frame.size.width-width)/2.0, (self.frame.size.height-44)+(44-30)/2.0, width, 30);
    self.titleLabel.frame = CGRectMake(0, 0, 10 + size.width + 10, self.backgroundView.frame.size.height);
    self.titleLabel.text = title;
    self.arrowButton.frame = CGRectMake(self.titleLabel.frame.origin.x+self.titleLabel.frame.size.width, (self.backgroundView.frame.size.height-20)/2.0, 20, 20);
}

@end
